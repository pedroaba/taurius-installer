export function Separator() {
  return <span className="text-rotion-500">/</span>;
}
