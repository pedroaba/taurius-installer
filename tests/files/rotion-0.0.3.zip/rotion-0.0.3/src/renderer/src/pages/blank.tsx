export function BlankPage() {
  return (
    <main className="flex-1 flex items-center justify-center text-rotion-400">
      Selecione ou crie um arquivo
    </main>
  );
}
